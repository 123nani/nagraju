//
//  PokemonView.swift
//  Test
//
//  Created by Gollapalli Nagaraju on 12/10/23.
//
import SwiftUI
import Foundation
struct PokemonView: View {
    
    var pokemon: Pokemon

    var body: some View {
        HStack {
            AsyncImage(url: pokemon.imageUrl) { image in
                image
                    .image?
                    .resizable()
            }
            .scaledToFit()
            .frame(width: 100, height: 100)
            Text(pokemon.name)
        }
    }
}


