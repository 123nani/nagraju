//
//  PokemonViewModel.swift
//  Test
//
//  Created by Gollapalli Nagaraju on 12/10/23.
//

import Foundation

class PokemonViewModel: ObservableObject {
    @Published var pokemonList: [Pokemon] = []

    func getPokemonList() async throws -> [Pokemon] {
       // print("Current configuration: \(BuildConfiguration.shared.environment)")

        guard let url = URL(string: "https://pokeapi.co/api/v2/pokemon?limit=50") else {
            throw URLError(.badURL)
        }
        
        let request = URLRequest(url: url)
        let (data, response) = try await URLSession.shared.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse, 200..<300 ~= httpResponse.statusCode else {
            throw URLError(.badServerResponse)
        }
        
        var pokemons = [Pokemon]()
        
        let pokemonList = try JSONDecoder().decode(PokemonList.self, from: data)
        
        for (index, result) in pokemonList.results.enumerated() {
            let pokemon = Pokemon(id: index + 1, name: result.name)
            pokemons.append(pokemon)
        }
        
        return pokemons
    }
    
}
