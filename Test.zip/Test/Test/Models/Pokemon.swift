//
//  Pokemon.swift
//  Test
//
//  Created by Gollapalli Nagaraju on 12/10/23.
//

import Foundation

struct Pokemon: Identifiable, Decodable {
    let id: Int
    let name: String
    var imageUrl: URL? {
        return URL(string: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/\(id).png")
    }
}

struct PokemonList: Decodable {
    let results: [PokemonResult]
}

struct PokemonResult: Decodable {
    let name: String
    let url: String
}
