//
//  TestApp.swift
//  Test
//
//  Created by Gollapalli Nagaraju on 12/10/23.
//

import SwiftUI

@main
struct TestApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
